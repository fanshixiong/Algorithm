### DNF的编程实现

- 文件说明

```txt
dfa_in*.dfa     为输入文件，共3个
dfa_out.dfa     为输出文件，输出内容会放在末尾，内容多了可以删除
DFA.cpp         代码
```

代码内容为DFA的编程实现，具体细节见[DFA编程实现](http://blog.csdn.net/qq_34194662/article/details/79616435)。
