### 仿tiny词法分析

- 文件说明

```txt
input.math      输入文件
mathLex.cpp     代码
```

代码内容为仿tiny词法分析的编程实现，具体细节见[词法分析程序](http://blog.csdn.net/qq_34194662/article/details/79630091)。
