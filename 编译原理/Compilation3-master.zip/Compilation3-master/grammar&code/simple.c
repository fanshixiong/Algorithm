int main(int x, float y)
{
	int a;
	int b;
	float d[5][4];

	float a;
	a=5;
	k=5;

    while( a>b )
    {
        a=2;
    }
    a=1;
    b=a;

	if( a>b && b<0 )
		{
		 a=b+1;
		}
		else
			{
				b=a+1;
			}

	return 0;
}
